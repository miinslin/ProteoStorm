/*
 * IonMass.cpp
 *
 *  Created on: May 14, 2013
 *      Author: jsnedecor
 */

#include "IonMass.h"

namespace specnets
{
  IonMass::IonMass()
  {
    m_mass = 0.0;
    m_name = "";
    m_index = 0;
  }
}
